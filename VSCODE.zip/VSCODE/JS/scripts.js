//função que chama o HTML//


    function ContaLink(){
   window.location='https://pt.wikipedia.org/wiki/Nymphicus_hollandicus';
    }
    function ContaGit(){
        window.location='https://github.com/CritzyInfer';
         }